var json = 
[
    {name: "15.04.2012<br />12:15 AM", info: {value: 64, label: '64%', type: 'Custom Quiz', avgResponse: '00:27', avgDifficulty: '47 / 60', totalTime: '34:12'}},
    {name: "19.04.2012<br />01:05 PM", info: {value: 67, label: '67%', type: 'Custom Quiz', avgResponse: '00:27', avgDifficulty: '47 / 60', totalTime: '34:12'}},
    {name: "21.04.2012<br />05:21 PM", info: {value: 41, label: 'V41', type: 'Verbal Test', avgResponse: '00:27', avgDifficulty: '47 / 60', totalTime: '34:12'}},
    {name: "27.04.2012<br />12:47 AM", info: {value: 72, label: '72%', type: 'Custom Quiz', avgResponse: '00:27', avgDifficulty: '47 / 60', totalTime: '34:12'}},
    {name: "29.04.2012<br />07:01 PM", info: {value: 13, label: 'Q13', type: 'Quantitative Test', avgResponse: '00:27', avgDifficulty: '47 / 60', totalTime: '34:12'}},
    {name: "01.05.2012<br />03:33 PM", info: {value: 39, label: 'Q39', type: 'Quantitative Test', avgResponse: '00:27', avgDifficulty: '47 / 60', totalTime: '34:12'}},
    
    
    /* {date: "15.04.2012<br />12:15 AM", type: "QUIZ", score: 64, label: '64%'},
    {date: "19.04.2012<br />01:05 PM", type: "QUIZ", score: 67, label: '67%'},
    {date: "21.04.2012<br />05:21 PM", type: "TEST", score: 41, label: 'V41'},
    {date: "27.04.2012<br />12:47 AM", type: "QUIZ", score: 72, label: '72%'},
    {date: "29.04.2012<br />07:01 PM", type: "TEST", score: 13, label: 'Q13'},
    {date: "01.05.2012<br />03:33 PM", type: "TEST", score: 39, label: 'Q39'} */
    
    /* "data": 
    [
        {name: "15.04.2012 12:15 AM", color: '#3681C0', y: 28},
        {name: "19.04.2012 01:05 PM", color: '#3681C0', y: 32},
        {name: "21.04.2012 05:21 PM", color: '#1BA926', y: 41},
        {name: "27.04.2012 12:47 AM", color: '#3681C0', y: 46},
        {name: "29.04.2012 07:01 PM", color: '#1BA926', y: 13},
        {name: "01.05.2012 03:33 PM", color: '#1BA926', y: 39}
    ],*/
    /*
    "data": 
    [
        {x: Date.UTC(2012, 04, 15, 12, 15), name: "15.04 12:15", dataLabels: ['123'], color: 'red', y: 28},
        {x: Date.UTC(2012, 04, 19, 13, 05), name: "19.04 13:05", y: 32},
        {x: Date.UTC(2012, 04, 21, 17, 21), name: "21.04 17:21", y: 41},
        {x: Date.UTC(2012, 04, 27, 12, 47), name: "27.04 12:47", y: 46},
        {x: Date.UTC(2012, 04, 29, 19, 01), name: "29.04 19:01", y: 13},
        {x: Date.UTC(2012, 05, 01, 15, 33), name: "01.05 15:33", y: 39}
    ],
    */
];